<?php
//include_once($_SERVER['DOCUMENT_ROOT'].'/woocommerce/wp-config.php' );
global $wpdb;
// changing price at add to cart
add_action( 'woocommerce_before_calculate_totals', 'add_custom_price' );
function add_custom_price( $cart_object ) {
	$discount_product=array();
	global $wpdb;
	$discount_price = array();
	$tablename=$wpdb->prefix.'discount_form';
	$result=$wpdb->get_results( "SELECT * FROM wp_discount_form");
	foreach ( $result as $print ){
		$discount_product_id = $print->prdct_specified;
		$discount_percentage = $print->percentage;
		if($discount_product_id != ''){
		$discount_product[]=$discount_product_id;
		$discount_price[$discount_product_id]=$discount_percentage;
		//$prdct = $prdct_specified->get_name();  
		}
	}
	foreach ( $cart_object->cart_contents as $key => $value ) {
		$cart_product_id = $value['product_id'];
		if (in_array($cart_product_id, $discount_product)){
			$product = wc_get_product( $cart_product_id );
			$cart_price = $product->get_price();
			$dicunt_price = $discount_price[$cart_product_id];	
			$result_price = ($cart_price * $dicunt_price) / 100;
			$final_price = $cart_price - $result_price;	
			$value['data']->set_price($final_price);
			$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where product_id='$cart_product_id'");
			if($rowcount != 0 ){
							$in = $wpdb->query("update `wp_freeproduct` set status ='1' where product_id='$cart_product_id'");
							
			}
					//	$value['data']->set_price(0);
		}
		
	} 
} 
// changing price at cart total
add_filter( 'woocommerce_calculated_total', 'custom_calculated_total', 10, 2 );
//add_action( 'woocommerce_review_order_before_order_total', 'custom_calculated_total' );
//add_filter( 'woocommerce_calculated_total', 'custom_calculated_total', 10, 2 );

function custom_calculated_total( $total, $cart ){
	global $wpdb;
			//$tablename=$wpdb->prefix.'discount_form';
			$result=$wpdb->get_results( "SELECT * FROM wp_discount_form where on_page ='cart-total'");
			$rowcount = $wpdb->num_rows;
			if($rowcount != 0){
				$custom_amount = $result[0]->currency;
				$discount_percentage = $result[0]->percentage;
				$on_page = $result[0]->on_page;
		//echo	$total = strstr($total, '.', true);
				if(!empty($custom_amount)){
					if($on_page == "cart-total"){
						if($total >= $custom_amount){
							$cart_total = ($total * $discount_percentage) / 100;
							//return WC()->cart->total = round( $total - $cart_total);	
							return WC()->cart->total = round($total - $cart_total);	
						}else{ 
						return WC()->cart->total=round($total);
						}
					}else{ 
						return WC()->cart->total=round($total);	
					} 
			}
			}else{ 
				  return WC()->cart->total=round($total);	
			} 
}

// add free products on cart
add_action('woocommerce_check_cart_items', 'cart_free_product' );
function cart_free_product($cart_object) { // Cart's Total Excluding Taxes
	global $wpdb;
	$free_product_id =array();
	$prdct_specified =array();
	$gifts_product=array();
	$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct");
	foreach( $result as $cart_free_product ){
		 $prdct_specified_id=$cart_free_product->prdct_specified;
		$prdct_specified[]=$prdct_specified_id;
	}
	foreach( WC()->cart->get_cart() as $cart_item ){
		$product_id = $cart_item['product_id'];
		$prdct_specified;
		if (in_array($product_id, $prdct_specified)){
			$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where prdct_specified ='$product_id'");
			/* echo "<pre>";
			print_R($result); */
			$in=$wpdb->get_results( "SELECT * FROM wp_freeproduct where product_id='$product_id' AND status='1'");
			$rowcount = $wpdb->num_rows;
			if($rowcount != 0){}
			else{
				foreach($result as $print){
					$gifts_product[$print->id] = $print->product_id;
				}
			}
		}
	}


	
	if(!empty($gifts_product)){
		add_action( 'woocommerce_cart_actions', 'move_proceed_button' );
		function move_proceed_button( $checkout ) {
			echo '<input type="hidden" class="for_url" value="'. site_url() .'/wp-admin/admin.php?page=delete-free-prdct">';
			echo '<a class="button myBtn">Choose Gifts</a>';
		
		}
	}
	?>
			<!-- The Modal -->
	<div id="myModal" class="modal">
		<div class="wfg-overlay" style=""></div>
		<div class="wfg-popup">
			<h2 class="wfg-title">Choose your free gift    </h2>
			<div class="wfg-gifts">
				<form class="gifts_product" method="post">
				
		<?php	
		
		foreach(array_unique($gifts_product) as $key=>$print){
						$product = wc_get_product( $print );
							 $result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where product_id='$print' AND status='1'");
							 $rowcount = $wpdb->num_rows;
							 $checked="";
							 if($rowcount != 0 ){
								
							 $checked ="checked";
							
							 }
							 
							 ?>
			
						<div class="wfg-gift-item">
							<div class="wfg-heading">
								<input type="checkbox" class="free_checkbox" name="free_items[]" id="wfg-item-<?php echo $print;?>" value="<?php echo $key;?>" <?php echo $checked;?>>
								<label for="wfg-item-<?php echo $print;?>" class="wfg-title">
								  
								<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $print), 'single-post-thumbnail' );?>
								<img src="<?php  echo $image[0]; ?>" style="width:150px; height:150px;" alt="">
								</label>
								<h3><?php echo $product->get_title();?></h3>
							</div>
						</div>
		<?php	}?>
					<div class="wfg-actions">
						<input type="submit" value="Add Gifts" name="free_btnb" class="button wfg-button wfg-add-gifts">
						<button class="button wfg-button close" type="button">No Thanks</button>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php			


		error_reporting(0);
		if(isset($_POST['free_btnb'])){
						//update free product price on cart page	
		  add_action( 'woocommerce_before_calculate_totals', 'update_free_product_price' );
			function update_free_product_price($cart_object) {
			$actual_link = (isset($_SERVER['HTTPS']) ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
				$free_items=$_POST['free_items'];
				
				foreach($free_items as $free_items_val){
					foreach ( $cart_object->cart_contents as $key => $value ) {
						global $wpdb;
						$cart_product_id = $value['product_id'];
						$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where id='".$free_items_val."'");
						$product_id =$result[0]->product_id;
						
						if ($cart_product_id == $product_id){
							
							global $wpdb;
							$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where product_id='$cart_product_id' AND id='".$free_items_val."'");
							 $rowcount = $wpdb->num_rows;
							if($rowcount != 0 ){
								$in = $wpdb->query("update `wp_freeproduct` set status ='1' where product_id='$cart_product_id' AND id='".$free_items_val."'");
								$value['data']->set_price(0);
								echo "<script>window.location = '".$actual_link."'</script>";
							}
						}
					
					} 
				}
			} 
			$update_price=array();
			$free_items=$_POST['free_items'];
			foreach($free_items as $item_id){	
				$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where id='$item_id'");
				
				//$update_price[] = $item_id;
				$free_product_id =$result[0]->product_id; // Incentive product we are giving away
			
				$cart_id = WC()->cart->generate_cart_id( $free_product_id ); // (equivalent to $prod_unique_id)
				
				$free_products_in_cart = WC()->cart->find_product_in_cart( $cart_id );
				
				$cart_amount = WC()->cart->subtotal; // cart subtotal
				$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where prdct_specified ='$free_product_id'");
				$rowcount = $wpdb->num_rows;
					if($rowcount != 0 ){
					$in = $wpdb->query("update `wp_freeproduct` set status ='0' where prdct_specified='$free_product_id'");	
					}
				WC()->cart->remove_cart_item( $free_products_in_cart );
			
				WC()->cart->add_to_cart( $free_product_id, 1 ); 				
			}
 
		}
}

       //Get free product from table and remain price 0
	  add_action( 'woocommerce_before_calculate_totals', 'update_free_product_price_cart' );
			function update_free_product_price_cart($cart_object) {
			
				foreach ( $cart_object->cart_contents as $key => $value ) {
					$cart_product_id = $value['product_id'];
					global $wpdb;
						$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where product_id='$cart_product_id' AND status='1'");
						$rowcount = $wpdb->num_rows;
						if($rowcount != 0 ){
							$value['data']->set_price(0);
				
					}
				} 
			} 
	//hook for update free product quantity
add_filter('woocommerce_after_cart_item_quantity_update', 'update_cart_item_quantity', 10, 3 );	
add_filter( 'woocommerce_cart_item_quantity', 'update_cart_item_quantity', 10, 2 );
function update_cart_item_quantity( $product_quantity, $cart_item_key ){
	$cart_item = WC()->cart->cart_contents[ $cart_item_key ];
	$product_id =  $cart_item['product_id'];
	global $wpdb;
	$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where product_id='$product_id' AND status='1'");
	$rowcount = $wpdb->num_rows;
	if($rowcount != 0 ){
        $product_quantity ='1';
		return $product_quantity;
	}else{
		return $product_quantity;
	}
}
//reset free product price from zero to original			
add_action( 'woocommerce_thankyou', 'update_status_free_product', 10, 1 );
function update_status_free_product( $order_id ) {
	 global $wpdb;
	$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where status='1'");
	$rowcount = $wpdb->num_rows;
	if($rowcount != 0 ){
		$in = $wpdb->query("update `wp_freeproduct` set status ='0'");
	}
 
}
?>
