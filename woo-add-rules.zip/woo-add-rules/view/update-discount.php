
<?php
error_reporting(0);
	global $wpdb;
	if ( isset( $_POST['free_prdct'] ) ){
		global $wpdb;
		$tablename=$wpdb->prefix.'discount_form';
		$update_id = $_POST['update_id']; 
		$rule_name = $_POST['rule_name']; 
		$discount_on = $_POST['discount_on']; 
		$percentage = $_POST['percentage']; 
		$on_page = $_POST['on_page']; 
		$prdct_specified = $_POST['prdct_specified']; 
		$currency = $_POST['currency']; 
		if($currency == ''){
			$result=$wpdb->get_results( "SELECT * FROM wp_discount_form where prdct_specified='$prdct_specified'");
			$check_prdct = $result[0]->prdct_specified;
			$check_percentage = $result[0]->percentage;
			if($check_prdct == ''){
				
				$insert = $wpdb->query("UPDATE `$tablename` SET rule_name='$rule_name', discount_type='$discount_on', percentage='$percentage', on_page='$on_page', prdct_specified='$prdct_specified',currency='' where id='$update_id'"); 
			}elseif($check_percentage != $percentage && $check_prdct == $prdct_specified){
				$insert = $wpdb->query("UPDATE `$tablename` SET rule_name='$rule_name', discount_type='$discount_on', percentage='$percentage', on_page='$on_page',currency='' where id='$update_id'"); 
			}else{
				echo '<script language="javascript">';
				echo 'alert("You already assigned value this product")';
				echo '</script>';
			}
		}else{
			$result=$wpdb->get_results( "SELECT * FROM wp_discount_form where on_page='$on_page'");
			$cart_page = $result[0]->on_page;
			$cart_currency = $result[0]->currency;
			$cart_percentage = $result[0]->percentage;
			
			if($cart_page != "cart-total"){
				$insert = $wpdb->query("UPDATE `$tablename` SET rule_name='$rule_name', discount_type='$discount_on', percentage='$percentage', on_page='$on_page', currency='$currency',prdct_specified='' where id='$update_id'"); 
			}elseif($cart_currency != $currency && $cart_page == $on_page){
				$insert = $wpdb->query("UPDATE `$tablename` SET rule_name='$rule_name', discount_type='$discount_on', percentage='$percentage',currency='$currency',prdct_specified='' where id='$update_id'"); 
			}elseif($cart_percentage != $percentage && $cart_page == $on_page){
				$insert = $wpdb->query("UPDATE `$tablename` SET rule_name='$rule_name', discount_type='$discount_on', percentage='$percentage',prdct_specified='' where id='$update_id'"); 
			}else{
				echo '<script language="javascript">';
				echo 'alert("You already assigned Amount on cart total")';
				echo '</script>';
			}
		}
		if($insert){
			echo "<script>window.location = '".site_url()."/wp-admin/admin.php?page=discount-list'</script>";
		}
	}
?>
<head>
  <link href="<?php echo MY_PLUGIN_URL; ?>/css/style.css" rel="stylesheet">
  
</head>
<style>
.currency{
	display:none;
}
.specified_prdct{
		
}
.config_prdct{
	
}
</style>
<body>

<div class="wrap">
<h1 class="wp-heading-inline">Add Rules</h1>

<a  href="<?php echo site_url();?>/wp-admin/admin.php?page=discount-list" class="page-title-action">Discount Rules List</a>
 </div>
<?php
global $wpdb;
	$update_id=$_GET['update_id'];
	$result=$wpdb->get_results( "SELECT * FROM wp_discount_form where id='$update_id'");
 	/* echo "<pre>";
	print_r($result[0]);  */
?>
<div class="container">
  <form class="addrule" method="post" action="">
      <input type="hidden" value="<?php echo $result[0]->id; ?>" name="update_id">
    <label for="fname">Rule Name</label>
    <input type="text" value="<?php echo $result[0]->rule_name; ?>" name="rule_name" placeholder="" required>
	
	<label for="fname">Discount Type</label>
    <input type="text" value="<?php echo $result[0]->discount_type; ?>"  placeholder="" disabled>
	
    <input type="hidden" value="<?php echo $result[0]->discount_type; ?>" name="discount_on">
	
	<label for="fname">Percentage</label>
    <input type="text" value="<?php echo $result[0]->percentage; ?>" name="percentage" placeholder="" required>

<!--	<label for="fname">ON</label>
    <input type="text" value="<?php echo $result[0]->on_page; ?>" name="on_page" placeholder="">-->
	

	
	<?php 
	$Product_specific = $result[0]->on_page; 
	
	if($Product_specific == "Product-specific") {
	
	?>
			  <label>ON</label>
    <select  class="for_Cart_cnt" id="on_page" name="on_page" required/>
		<option id="discount_onpage" value="<?php echo $result[0]->on_page; ?>">Product specific</option>
		<option value="Product-specific">Product specific</option>
		<option id="for_Cart_cnt" value="cart-total">Cart Total</option>
    </select>
	<?php
	$specific_product_id=$result[0]->prdct_specified;;
	$prdct_specified = wc_get_product( $specific_product_id );
	$prdct = $prdct_specified->get_name(); 
		?>
		<div class="specified_prdct">
		 <label>Specified Product</label>
	  <select  id="prdct_specified" name="prdct_specified">
	  <option id="remove_specified" value="<?php echo $specific_product_id; ?>"><?php echo $prdct; ?></option>
		
					<?php  

				$args = array(
					'post_type'      => 'product',
					'posts_per_page' => 1000
					
				);

				$loop = new WP_Query( $args );

				while ( $loop->have_posts() ) : $loop->the_post();
					global $product;
					$_product = wc_get_product( $product->get_id());
					if( $_product->is_type( 'simple' ) ) {
					?>
						<option value="<?php echo $product->get_id();?>"><?php echo get_the_title();?></option>
					<?php
					}  else {
					?>
						<option class="config_prdct" value="<?php echo $product->get_id();?>"><?php echo get_the_title();?></option>
					<?php
					}  
				endwhile;

				wp_reset_query();
			?>
			  </select>
			</div>
	<div class="currency">
		<label for="lname">Amount</label><span></span>
		<input id="cart_currency" type="text" value="" name="currency">
	</div>
			<?php
			
	}
	else{
			?>
	<label>ON</label>
    <select  id="on_page" name="on_page">
		<option id="discount_onpage" value="<?php echo $result[0]->on_page; ?>">Cart Total</option>
		<option value="cart-total">Cart Total</option>
		<option value="Product-specific">Product specific</option>
    </select>
	
			<div class="amount_discount">
			<label for="lname">Amount</label><span></span>
			<input id="amount" value="<?php echo $result[0]->currency; ?>" type="text" name="currency" required/>
			</div>
		<div style="display:none;"; class="specified_prdct">
		<label>Specified Product</label>
		<select  id="prdct_specified" name="prdct_specified">
			<option value="<?php echo $result[0]->prdct_specified; ?>">Select Product</option>
					<?php  

				$args = array(
					'post_type'      => 'product',
					'posts_per_page' => 1000
				);

				$loop = new WP_Query( $args );

				while ( $loop->have_posts() ) : $loop->the_post();
					global $product;
					$_product = wc_get_product( $product->get_id());
					if( $_product->is_type( 'simple' ) ) {
					?>
						<option value="<?php echo $product->get_id();?>"><?php echo get_the_title();?></option>
					<?php
					} else {
					?>
						<option class="config_prdct" value="<?php echo $product->get_id();?>"><?php echo get_the_title();?></option>
					<?php
					} 
				endwhile;

				wp_reset_query();
			?>
			  </select>
			</div>
			
			<?php
	}
	$result=$wpdb->get_results( "SELECT * FROM wp_discount_form where on_page='cart-total'");
	$cart_count = $wpdb->num_rows;
			?>
   
    <input class="cart_count" type="hidden" name="" value="<?php echo $cart_count;?>">
    <input class="fre_prdct_btn" type="submit" name="free_prdct" value="Submit">
  </form>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://code.jquery.com/jquery-1.10.2.js"></script>

		<script type="text/javascript">
			$(document).ready(function() {
				$( "#on_page" ).change(function() {
					var on_page = $( "#on_page option:selected" ).val();
					if(on_page == "Product-specific"){
						$(".specified_prdct").css("display", "block");
						$(".currency").css("display", "none");
						$(".amount_discount").css("display", "none");
						$("#amount").val('');
						$(".fre_prdct_btn").css("display", "block");
						$('#prdct_specified').prop('required',true);
						$('#amount').prop('required',false);
						$('#cart_currency').prop('required',false);
						//$('input[type="submit"]').attr('disabled', '');
					/* 	var config_prdct = $( "#prdct_specified option:selected" ).val();
						if(config_prdct == "config"){
							$('input[type="submit"]').attr('disabled', '');
							alert("You Are Not Able to Add Configurable Product!");
						}else{
							$('input[type="submit"]').removeAttr('disabled');
						} */
					
					}
					if(on_page == "cart-total"){
						
						$(".specified_prdct").css("display", "none");
						$(".currency").css("display", "block");
						$(".amount_discount").css("display", "block");
						$(".fre_prdct_btn").css("display", "block");
						$('#prdct_specified').prop('required',false);
						$('#amount').prop('required',true);
						$('#cart_currency').prop('required',true);
						$('input[type="submit"]').removeAttr('disabled');
					
					}
				});
				$('#prdct_specified').click(function(){
					$('#remove_specified').css('display', 'none');
				});
				$('#on_page').click(function(){
					$('#discount_onpage').css('display', 'none');
				});
				
				$( ".for_Cart_cnt" ).change(function() {
					 var cart_total_page = $( ".for_Cart_cnt option:selected" ).val();
					//alert(cart_total_page); 
					var cart_count = $( ".cart_count" ).val();
					if(cart_total_page == "cart-total"){
						$(".specified_prdct").css("display", "none");
						if(cart_count != 0){
							//$("#for_Cart_cnt").val('');
							$(".specified_prdct").css("display", "none");
							$(".specified_prdct").css("display", "none");
							$(".fre_prdct_btn").css("display", "none");
							$(".currency").css("display", "none");
							alert("You already assigned Cart total")
						}else{
							//$(".specified_prdct").css("display", "block");
							$(".fre_prdct_btn").css("display", "block");
							$(".currency").css("display", "block");
						}
					}
				});
				
				//code for configurable product
			/* 	$( "#prdct_specified" ).change(function() {
					var config_prdct = $( "#prdct_specified option:selected" ).val();
					if(config_prdct == "config"){
						$('input[type="submit"]').attr('disabled', '');
						alert("You Are Not Able to Add Configurable Product!");
					}else{
						$('input[type="submit"]').removeAttr('disabled');
					}
				}); */
			});
</script>
