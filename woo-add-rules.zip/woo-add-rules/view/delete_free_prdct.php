<?php
//include_once($_SERVER['DOCUMENT_ROOT'].'/woocommerce/wp-config.php' );
global $wpdb;
$status_id = $_POST['remove_id'];
$result=$wpdb->get_results( "UPDATE wp_freeproduct set status= '0' where product_id='$status_id'");

$result=$wpdb->get_results( "UPDATE wp_freeproduct set status= '0' where prdct_specified='$status_id'");


/* 	$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where prdct_specified='$status_id'");
	$rowcount = $wpdb->num_rows;
	if($rowcount != 0){
		foreach($result as $print){
			$product_id = $print->product_id;
			$result=$wpdb->get_results( "UPDATE wp_freeproduct set status= '0' where product_id='$product_id'");
		}
	} */


?>