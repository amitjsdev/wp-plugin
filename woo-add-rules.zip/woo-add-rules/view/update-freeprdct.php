<?php
 global $wpdb;
/* 	if(isset($_GET['delete_id'])){
		$delete_id=$_GET['delete_id'];
		 $qryy_delete=$wpdb->query("DELETE  FROM  wp_freeproduct where id='$delete_id'"); 
		if($qryy_delete){
				// echo "sucess";
			}
		} */
	if ( isset( $_POST['free_prdct'] ) ){
		global $wpdb;
		$tablename=$wpdb->prefix.'freeproduct';
		$update_id = $_POST['update_id']; 
		$rule_name = $_POST['rule_name']; 
		$free_product = $_POST['discount_on']; 
		$product_name = $_POST['product_name']; 
		$product_id = $_POST['product_id']; 
		$on_page = $_POST['on_page']; 
		$prdct_specified = $_POST['prdct_specified']; 
		$previous_specified_id = $_POST['previous_specified_id']; 
		$currency = $_POST['currency']; 
		if($currency == ''){
			
			$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where prdct_specified='$prdct_specified'");
			$prdct_specified_count = $wpdb->num_rows;
			if($prdct_specified_count != 0){
				$check_prdct_id =array();
				foreach($result as $print){
					$check_prdct_id[] = $print->product_id;
				}
				
				//print_R($product_id);
				//print_R($check_prdct_id);
				
				//$result_val=array_diff($check_prdct_id,$product_id);
				$result_val=array_diff($product_id,$check_prdct_id);
				if(!empty($result_val)){
					foreach($product_id as $check_prdct_value){
						$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where product_id='$check_prdct_value' AND prdct_specified='$prdct_specified'");
						$prdct_count = $wpdb->num_rows;
						if($prdct_count != 0){
						$insert = $wpdb->query("UPDATE `wp_freeproduct` SET rule_name='$rule_name', free_product='$free_product',on_page='$on_page' where product_id='$check_prdct_value' AND prdct_specified='$prdct_specified'"); 
						}
						else{
							
							$insert = $wpdb->query("INSERT INTO `wp_freeproduct`(`rule_name`, `free_product`, `product_id`, `on_page`,`prdct_specified`) VALUES ('".$rule_name."', '".$free_product."', '".$check_prdct_value."', '".$on_page."', '".$prdct_specified."')");
						}
					}
				}else{
					$insert = $wpdb->query("UPDATE `wp_freeproduct` SET rule_name='$rule_name' where prdct_specified='$prdct_specified'");
					if($insert){}
					else{
					echo '<script language="javascript">';
					echo 'alert("You already assigned same free product to this product")';
					echo '</script>';
					}
				}
				
			}else{
				 $qryy_delete=$wpdb->query("DELETE  FROM  wp_freeproduct where prdct_specified='$previous_specified_id'"); 
				foreach($product_id as $n_product_id){
				$insert = $wpdb->query("INSERT INTO `wp_freeproduct`(`rule_name`, `free_product`, `product_id`, `on_page`,`prdct_specified`) VALUES ('".$rule_name."', '".$free_product."', '".$n_product_id."', '".$on_page."', '".$prdct_specified."')");
				}
			}
			
	
			if($insert){
				//echo "sucess";
					echo "<script>window.location = '".site_url()."/wp-admin/admin.php?page=freeprdct-list'</script>";
			}
		}
	}
?>
<head>
  <link href="<?php echo MY_PLUGIN_URL; ?>/css/style.css" rel="stylesheet">
  
</head>
<style>
.currency{
	display:none;
}
select#free_product {
    height: 138px;
}
.vM {
    display: inline-block;
    width: 14px;
    height: 20px;
    background: no-repeat url(<?php echo site_url();?>/wp-content/plugins/woo-add-rules/img/contactarea_sprite_2.gif) -4px 0;
    opacity: .6;
    vertical-align: top;
    cursor: pointer;
}
.config_prdct{

}
</style>
<body>

<div class="wrap">
<h1 class="wp-heading-inline">Add Rules</h1>

 <a  href="<?php echo site_url();?>/wp-admin/admin.php?page=freeprdct-list" class="page-title-action">Free Product List</a>
 </div>
<?php
global $wpdb;
	$update_id=$_GET['update_id'];
	$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where prdct_specified='$update_id'");
	
 	/* echo "<pre>";
	print_r($result[0]);  */
?>
<div class="container">
  <form class="addrule" method="post" action="">
      <input type="hidden" class="update_id" value="<?php echo $update_id; ?>" name="previous_specified_id">
    <label for="fname">Rule Name</label>
    <input type="text" value="<?php echo $result[0]->rule_name; ?>" name="rule_name" placeholder="" required>
	
	<label for="fname">Product Type</label>
    <input type="text" value="<?php echo $result[0]->free_product; ?>" name="" placeholder="" disabled>
    <input type="hidden" value="<?php echo $result[0]->free_product; ?>" name="discount_on" >
	<!--<div class="">
					 <label>Product Count</label>
				<?php
				$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where prdct_specified	='$update_id'");
				
				?>
			<span id="product-count" value="<?php echo $wpdb->num_rows;?>"><?php echo $wpdb->num_rows;?></span> 
	</div>-->
	<?php
				$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where prdct_specified	='$update_id'");
				$product_count = $wpdb->num_rows;
				if($product_count == 0){
					echo "<script>window.location = '".site_url()."/wp-admin/admin.php?page=freeprdct-list'</script>";
				}
	?>
	<div class="product-count" style="display: block;">
					 <label>Product Count</label>
		<select id="product-count" name="product_list">
				<option id="cnt_hide" value="<?php echo $wpdb->num_rows;?>"><?php echo $wpdb->num_rows;?></option>
	<?php
	$counts=0;
	$args = array(
					'post_type'      => 'product',
					'posts_per_page' => 1000
				);

				$loop = new WP_Query( $args );

				while ( $loop->have_posts() ) : $loop->the_post();
					global $product;
				$_product = wc_get_product( $product->get_id());
					if( $_product->is_type( 'simple' ) ) {
						
						$counts++;
					}

			endwhile;
			wp_reset_query();
	
		for($prd_cnt=1; $prd_cnt <= $counts; $prd_cnt++){
		?>
			 <option value="<?php echo $prd_cnt;?>"><?php echo $prd_cnt;?></option>
	<?php		
		}	
		?>
		</select>
	</div>
	<div class="slectpdct" style="display: block;">
	<?php
	foreach($result  as $free_product){
		$product_id = $free_product->product_id;
		if($product_id != ''){
			$product = wc_get_product( $product_id );
			$prdct_specified = $product->get_name(); ?>
	
			<div id="remove-<?php echo $product_id;?>" class="vR">
				<span  class="vN bfK a3q">
					<div class="vT"><?php echo $prdct_specified;?></div>
					<div id="<?php echo $product_id;?>" class="vM"></div>
				</span>
			</div>
			<input type="hidden" value="<?php echo $prdct_specified;?>" name="product_name[]"><input class="specified_product" type="hidden" value="<?php echo $product_id;?>" name="product_id[]">

	<?php
		}
	}
	?>
	</div>
	<label for="fname">Product Name</label>
					<select id="free_product" name="product_name" multiple required/>
			<!--	<option value="<?php echo $result[0]->product_id; ?>">Select Product</option>-->
				<?php  

				$args = array(
					'post_type'      => 'product',
					'posts_per_page' => 1000
				);

				$loop = new WP_Query( $args );

				while ( $loop->have_posts() ) : $loop->the_post();
					global $product;
					$_product = wc_get_product( $product->get_id());
					if( $_product->is_type( 'simple' ) ) {
					?>
						<option value="<?php echo $product->get_id();?>"><?php echo get_the_title();?></option>
					<?php
					} /* else {
					?>
						<option class="config_prdct" value="config"><?php echo get_the_title();?></option>
					<?php
					} */ 
				endwhile;

				wp_reset_query();
			?>
			</select>
			
  
	

	
	<?php 
	$Product_specific = $result[0]->on_page; 
	
	if($Product_specific == "Product-specific") {
	
	?>
	<label>ON</label>
    <select  id="on_page" name="on_page">
	 <option value="<?php echo $result[0]->on_page; ?>">Product specific</option>
      <!--<option value="cart-total">Cart Total</option>
      <option value="Product-specific">Product specific</option>-->
    </select>
	<?php
	//$specific_product_id=$_GET['update_id'];
	$specific_product_id=$update_id;
	$prdct_specified = wc_get_product( $specific_product_id );
	$prdct = $prdct_specified->get_name(); 
		?>
		<div class="specified_prdct">
		 <label>Specified Product</label>
	  <select  id="prdct_specified" name="prdct_specified">
	  <option id="remove_specified" value="<?php echo $specific_product_id; ?>"><?php echo $prdct; ?></option>
					<?php  

				$args = array(
					'post_type'      => 'product',
					'posts_per_page' => 1000
				);

				$loop = new WP_Query( $args );

				while ( $loop->have_posts() ) : $loop->the_post();
					global $product;
					$_product = wc_get_product( $product->get_id());
					if( $_product->is_type( 'simple' ) ){
					?>
						<option value="<?php echo $product->get_id();?>"><?php echo get_the_title();?></option>
					<?php
					} else {
					?>
						<option class="config_prdct" value="<?php echo $product->get_id();?>"><?php echo get_the_title();?></option>
					<?php
					} 
				endwhile;

				wp_reset_query();
			?>
			  </select>
			</div>

			<?php
			
	}
	else{
			?>



			
			<?php
	}
			?>
   
    <input class="fre_prdct_btn" type="submit" name="free_prdct" value="Submit">
  </form>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://code.jquery.com/jquery-1.10.2.js"></script>


		<script type="text/javascript">
		$(document).ready(function() {
				//code for select multiple option
			var last_valid_selection = null;
			$('#free_product').change(function(event) {
				var prdct_cnt = $('#free_product :selected').length;
				var nthcnt = $( "#product-count option:selected" ).val();
				if ($(this).val().length > nthcnt) {
				  $(this).val(last_valid_selection);
				}else {
				  last_valid_selection = $(this).val();
				} 
			});
			//code for multi select 
			//$('#free_product').val(['8','18');
			var selected_product_id=[];
			$('input[name^="product_id"]').each(function() {
				selected_product_id.push($(this).val());
			});
			$('#free_product').val(selected_product_id);	
			$('#free_product').change(function(event) {
				$(".slectpdct").html('');
				
				var comp_prdct_specified = $( "#prdct_specified option:selected" ).val();
				//alert(comp_prdct_specified);
				$('#free_product :selected').each(function(i, selectedElement) {
				//	alert("test");
					 if(selectedElement != '' ){
					var labeltext = $(selectedElement).text();
					// alert(labeltext);
					var labelvalues = $(selectedElement).val();
					// alert(labelvalues);
					 
					  $(".slectpdct").append('<div id="remove-'+labelvalues+'" class="vR"><span class="vN bfK a3q"><div class="vT">'+  labeltext +'</div><div id="'+labelvalues+'" class="vM"></div></div><input type="hidden" value="'+  labeltext +'" name="product_name[]"><input type="hidden" value="'+  labelvalues +'" name="product_id[]">'); 
					 if(comp_prdct_specified == labelvalues){
						 $( "#remove-"+labelvalues ).html('');
					 }
					}
				});
			});
			
			
		
				$( "#on_page" ).change(function() {
					var on_page = $( "#on_page option:selected" ).val();
					if(on_page == "Product-specific"){
						$(".specified_prdct").css("display", "block");
						$(".currency").css("display", "none");
						$(".amount_discount").css("display", "none");
						$("#amount").val('');
						$("#prdct_specified").prop('required',true);
					
					}else{
						$(".specified_prdct").css("display", "none");
						$(".currency").css("display", "block");
						$(".amount_discount").css("display", "block");
						var prdct_specified = $( "#prdct_specified option:selected" ).val();
						$('#prdct_specified option[value="'+prdct_specified+'"]').removeAttr("selected");
						$('#prdct_specified').trigger( "change" );
						$('#remove_specified').val('');
						$("#prdct_specified").prop('required',false);
					}
				});
			 	$('#free_product').change(function(event) {
					$('#prdct_specified').trigger( "change" );
				});  
				$('#prdct_specified').change(function(event) {
					var prdct_specified = null;
					var product_id = null;
					var product_id=[];
						$('input[name^="product_id"]').each(function() {
							var s_product_id = $(this).val();
							var cnt_product_id = $(this).val().length;
							//alert(cnt_product_id);
							if(cnt_product_id == 1){
								var s_product_id = "0"+s_product_id;
							}
							product_id.push(s_product_id);
						}); 
					var selected_prdct_id= "[" + product_id + "]";
					//var free_product = $( "#free_product option:selected" ).val();
					var prdct_val = $( "#prdct_specified option:selected" ).val();
					var int_prdct = prdct_val.length;
					//alert(int_prdct);
					if(int_prdct == 1){
					var prdct_val = "0"+prdct_val;
					}
					var free_product= selected_prdct_id.indexOf(prdct_val);
					if(free_product != -1){
						//if(discount == "free-product"){
						$('.fre_prdct_btn').attr('disabled', '');
						alert("You Are Not Able to Select same Product!");
					}else{
						$('input[type="submit"]').removeAttr('disabled');
						//alert("else"+discount);
					}
				}); 
				
				$('#prdct_specified').click(function(){
					$('#remove_specified').css('display', 'none');
				});
				
				$('#product-count').click(function(){
					$('#cnt_hide').css('display', 'none');
				});
				

				
		});
</script>


		<script>
			$(document).on('click',  '.vM', function(){
				$.urlParam = function(name){
					var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
					return results[1] || 0;
				}
				 var update_id = $.urlParam('update_id');
				
				  var x = confirm("Are you sure you want to delete?");
				 if (x == true){
					//alert((this).attr("href"));
					var id =  $(this).attr('id');
					$( "#remove-"+id ).html('');
					var p_url = '<?php echo site_url();?>/wp-admin/admin.php?page=remove-free-prdct';
					var value={'remove_id': id,'update_id':update_id};
					jQuery.ajax({
						type: "POST",	
						url: p_url,
						data: value, 
						success: function(data){
							//myfunction();
							//alert(data);
							//location.reload();
						}
					});
					//alert(id);
					$('#free_product option[value="'+id+'"]').removeAttr("selected");
					$('#free_product').trigger( "change" );
					//$('#prdct_specified').trigger( "change" );
			
					return true;
				}else{
					return false;
				}
			//}
			});
</script>