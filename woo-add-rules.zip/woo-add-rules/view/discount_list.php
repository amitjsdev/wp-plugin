<?php
 global $wpdb;
	if(isset($_GET['delete_id'])){
		$delete_id=$_GET['delete_id'];
		 $qryy_delete=$wpdb->query("DELETE  FROM  wp_discount_form where id='$delete_id'"); 
		if($qryy_delete){
				 echo "sucess";
		}
	}
				
?>
<head>
  <link href="<?php echo MY_PLUGIN_URL; ?>/css/style.css" rel="stylesheet">
</head>
<style>
.fre_prdct_btn{
	display:none;
}
.no_records{
	text-align: center;
}
</style>

		<div class="wrap">
			<h1 class="wp-heading-inline">Discount Rules List</h1>
			<a  href="<?php echo site_url();?>/wp-admin/admin.php?page=add-form" class="page-title-action">Add New Rule</a>
			<a  href="<?php echo site_url();?>/wp-admin/admin.php?page=freeprdct-list" class="page-title-action">Free Product List</a>
		</div>
<?php
			global $wpdb;
			$result=$wpdb->get_results( "SELECT * FROM wp_discount_form");
			$result_count = $wpdb->num_rows;
			if($result_count != 0){
?>
				<table class="wp-list-table widefat fixed striped users">
					<thead>
						<tr>
							<th scope="col"  class="manage-column column-role">S No.</th>
							<th scope="col"  class="manage-column column-name">Rule Name</th>
							<th scope="col"  class="manage-column column-name">Disocunt Type</th>
							<th scope="col"  class="manage-column column-name">Percentage</th>
							<th scope="col" id="name" class="manage-column column-name">ON</th>
							<th scope="col" id="name" class="manage-column column-name">Specified Product</th>
							<th scope="col" id="name" class="manage-column column-name">Amount</th>
							<th scope="col"  class="manage-column column-role">Action</th>
						</tr>
					</thead>
					<tbody id="the-list" data-wp-lists="list:user">
						   <?php
					global $wpdb;
					$a=1;
					$tablename=$wpdb->prefix.'discount_form';
					$result=$wpdb->get_results( "SELECT * FROM wp_discount_form");
					
							foreach ( $result as $print ){
								$free_product_id = $print->prdct_specified;
								if($free_product_id != ''){
									$prdct_specified = wc_get_product( $free_product_id );
									$prdct = $prdct_specified->get_name();  
								}
								else{
										$prdct = "-"; 
								} 
									?>
											<tr>
												<th><?php echo $a; ?></th>
												<td class="username column-username has-row-actions column-primary" data-colname="Username">
												<?php echo $print->rule_name;  ?>
												</td>
												<td class="name column-name" data-colname="Name"><?php echo $print->discount_type; ?></td>
												<td class="name column-name" data-colname="Name"><?php echo $print->percentage; ?></td>
												<td class="name column-name" data-colname="Name"><?php echo $print->on_page ; ?></td>
												<td class="name column-name" data-colname="Name"><?php echo $prdct; ?></td>
												<td class="name column-name" data-colname="Name"><?php echo $print->currency; ?></td>
												<td class="role column-role" data-colname="Role"><a class="button-primary app_view" href="<?php echo site_url();?>/wp-admin/admin.php?page=update-discount&update_id=<?php echo $print->id; ?>">Edit</a>
												<a  class="button-primary app_delete" href="<?php echo site_url();?>/wp-admin/admin.php?page=discount-list&delete_id=<?php echo $print->id; ?>" Onclick="return ConfirmDelete();">Delete</a></td>
											</tr>	
				<?php			$a++;
							}
						?>	
					</tbody>
				</table>
		<?php
				}else{
		?>
					<div class="no_records">
					<h1>No records found</h1>
					</div>
		<?php
				}
		?>
		<script>

function ConfirmDelete(){

  var x = confirm("Are you sure you want to delete?");
  if (x)
      return true;
  else
    return false;
}
</script>