
<?php

global $wpdb;
if ( isset( $_POST['discount'] ) ){
  $tablename=$wpdb->prefix.'discount_form';
	$rule_name = $_POST['rule_name']; 
    $discount_type = $_POST['discount_on']; 
    $percentage = $_POST['percent']; 
    $on_page = $_POST['on_page']; 
    $prdct_specified = $_POST['prdct_specified']; 
    $currency = $_POST['currency']; 
	if($prdct_specified != ''){
		$result=$wpdb->get_results( "SELECT * FROM wp_discount_form where prdct_specified='$prdct_specified'");
		$check_prdct = $result[0]->prdct_specified;
		if($check_prdct == ''){
			$in = $wpdb->query("INSERT INTO `$tablename`(`rule_name`, `discount_type`, `percentage`, `on_page`,`prdct_specified`) VALUES ('".$rule_name."', '".$discount_type."', '".$percentage."', '".$on_page."', '".$prdct_specified."')");
		}else{
				echo '<script language="javascript">';
				echo 'alert("You already assigned Offer this product")';
				echo '</script>';
			
		}
	}
	else{
		$result=$wpdb->get_results( "SELECT * FROM wp_discount_form where on_page='$on_page'");
		$cart_page = $result[0]->on_page;
		if($cart_page != "cart-total")
		{
			$in = $wpdb->query("INSERT INTO `$tablename`(`rule_name`, `discount_type`, `percentage`, `on_page`,`currency`) VALUES ('".$rule_name."', '".$discount_type."', '".$percentage."', '".$on_page."', '".$currency."')");
		}
		else{
				echo '<script language="javascript">';
				echo 'alert("You already assigned Amount on cart total")';
				echo '</script>';
		}
	}


	 if($in){
		echo '<script language="javascript">';
		echo 'alert("Offer added successfully!")';
		echo '</script>';
	 }
}


if ( isset( $_POST['free_prdct'] ) ){

    global $wpdb;
	
  $tablename=$wpdb->prefix.'freeproduct';
  
    $rule_name = $_POST['rule_name']; 
    $free_product = $_POST['discount_on']; 
    $product_name = $_POST['product_name']; 
    $product_id = $_POST['product_id']; 
    $on_page = $_POST['on_page']; 
    $prdct_specified = $_POST['prdct_specified']; 
    $currency = $_POST['currency']; 
		
			
	   if($prdct_specified != ''){
			$result=$wpdb->get_results( "SELECT * FROM wp_freeproduct where prdct_specified='$prdct_specified'");
			$check_prdct = $result[0]->prdct_specified;
			if($check_prdct == ''){
				foreach($product_id as $key=>$value){

					$insert = $wpdb->query("INSERT INTO `$tablename`(`rule_name`, `free_product`, `product_name`, `product_id`, `on_page`,`prdct_specified`) VALUES ('".$rule_name."', '".$free_product."', '".$product_name[$key]."', '".$product_id[$key]."', '".$on_page."', '".$prdct_specified."')");
				}
			}else{
					echo '<script language="javascript">';
					echo 'alert("You already assigned free product for this product")';
					echo '</script>';
				
			}
		}else{
			$result=$wpdb->get_results( "SELECT * FROM wp_discount_form where prdct_specified='$prdct_specified'");
			$cart_page = $result[0]->on_page;
			if($cart_page != "cart-total"){
				$in = $wpdb->query("INSERT INTO wp_discount_form(`rule_name`, `discount_type`, `percentage`, `on_page`,`currency`) VALUES ('".$rule_name."', 'discount-product', '".$percentage."', '".$on_page."', '".$currency."')");
		
			}else{
						echo '<script language="javascript">';
						echo 'alert("You already assigned value this product")';
						echo '</script>';
					
			}
 
		}	 
		if($insert){
			echo '<script language="javascript">';
			echo 'alert("Offer added successfully!")';
			echo '</script>';
		}
}
?>
<head>
  <link href="<?php echo MY_PLUGIN_URL; ?>/css/style.css" rel="stylesheet">
  
</head>
<style>
.vM {
    display: inline-block;
    width: 14px;
    height: 20px;
    background: no-repeat url(<?php echo site_url();?>/wp-content/plugins/woo-add-rules/img/contactarea_sprite_2.gif) -4px 0;
    opacity: .6;
    vertical-align: top;
    cursor: pointer;
}
.fre_prdct_btn{
	display:none;
}
.specified_prdct {
   /*  float: left;
    padding: 3px; */
}
.submit-btn{
	width:50%
}
.specified_prdct{
	display:none;
}
.config_prdct{
	
}
</style>
<body>

<div class="wrap">
<h1 class="wp-heading-inline">Add Rules</h1>

 <a  href="<?php echo site_url();?>/wp-admin/admin.php?page=freeprdct-list" class="page-title-action">Free Product Rules List</a>
 <a  href="<?php echo site_url();?>/wp-admin/admin.php?page=discount-list" class="page-title-action">Discount Rules List</a>
 </div>

<div class="container">
  <form class="addrule" method="post" action="">
    <label for="fname">Name</label>
    <input type="text" name="rule_name" required/>
	
    <label>Type</label>
    <select id="discount" name="discount_on" required/>
      <option value="discount-product">Discount</option>
      <option value="free-product">Free product</option>
    </select>
	
	<div class="product-count">
					 <label>Product Count</label>
				<select id="product-count" name="product_list">
	<?php
	$counts=0;
	$args = array(
					'post_type'      => 'product',
					'posts_per_page' => 1000
				);

				$loop = new WP_Query( $args );

				while ( $loop->have_posts() ) : $loop->the_post();
					global $product;
				$_product = wc_get_product( $product->get_id());
					if( $_product->is_type( 'simple' ) ) {
						
						$counts++;
					}

			endwhile;
			wp_reset_query();
	
		for($prd_cnt=1; $prd_cnt <= $counts; $prd_cnt++){
		?>
			  <option value="<?php echo $prd_cnt;?>"><?php echo $prd_cnt;?></option>
	<?php		
		}	
		?>
		</select>
	</div>
	
				
		<div class="slectpdct"></div>		
	<div class="product-list">
					 <label>Product List</label>
					 
				<select id="userRequest_activity" name="product_list[]"  multiple="multiple"/>
				
				<?php  

				$args = array(
					'post_type'      => 'product',
					'posts_per_page' => 1000
				);

				$loop = new WP_Query( $args );

				while ( $loop->have_posts() ) : $loop->the_post();
					global $product;
				$_product = wc_get_product( $product->get_id());
					if( $_product->is_type( 'simple' ) ) {
					?>
						<option value="<?php echo $product->get_id();?>"><?php echo get_the_title();?></option>
					<?php
					}  /* else {
					?>
						<option class="config_prdct" value="<?php echo $product->get_id();?>"><?php echo get_the_title();?></option>
					<?php
					}  */ 
				endwhile;

				wp_reset_query();
			?>
			</select>
	</div>
	<div class="values">
    <label for="lname">Values </label><span>%</span>
    <input id="value" type="text" name="percent" required/>
	</div>
	
    <label>ON</label>
    <select  id="on_page" name="on_page" required/>
	<option value="">Select Option</option>
      <option id="cart_total" value="cart-total">Cart total</option>
      <option value="Product-specific">Product specific</option>
    </select>
	<div class="specified_prdct">
	  <select  id="prdct_specified" name="prdct_specified"/>
	  <option value="">Select Product</option>
					<?php  

				$args = array(
					'post_type'      => 'product',
					'posts_per_page' => 1000
					
				);

				$loop = new WP_Query( $args );

				while ( $loop->have_posts() ) : $loop->the_post();
						global $product;
					$_product = wc_get_product( $product->get_id());
					if( $_product->is_type( 'simple' ) ) {
					?>
						<option value="<?php echo $product->get_id();?>"><?php echo get_the_title();?></option>
					<?php
					} else {
					?>
						<option class="config_prdct" value="<?php echo $product->get_id();?>"><?php echo get_the_title();?></option>
					<?php
					} 
				endwhile;

				wp_reset_query();
			?>
			  </select>
			</div>
			
			<div class="currency">
    <label for="lname">Amount</label><span></span>
    <input id="amount" type="text" name="currency" required/>
	</div>
	<div class="submit-btn">
    <input class="discount_btn" type="submit" name="discount" value="Submit">
    <input class="fre_prdct_btn" type="submit" name="free_prdct" value="Submit">
	</div>
  </form>
</div>

<script>

/* function ConfirmDelete(){

  var x = confirm("Are you sure you want to delete?");
  if (x)
      return true;
  else
    return false;
} */
</script>
				
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script src="https://code.jquery.com/jquery-1.10.2.js"></script>

		<script type="text/javascript">
			$(document).ready(function() {
			
			
			$( "#discount" ).change(function() {
				var discount = $( "#discount option:selected" ).val();
				 //alert(discount);
					if(discount == "free-product"){
						//alert("shoulb be");
						 $(".product-list").css("display", "block");
						$(".product-count").css("display", "block");
						$(".values").css("display", "none");
						$(".discount_btn").css("display", "none");
						$(".fre_prdct_btn").css("display", "block");
						$('#value').prop('required',false);
						$('#userRequest_activity').prop('required',true);
						$(".product-count").prop('required',true);
						$(".slectpdct").css("display", "block"); 
						$("#cart_total").css("display", "none"); 
						$(".currency").css("display", "none"); 
						var on_page = $( "#on_page option:selected" ).val();
						$('#on_page option[value="'+on_page+'"]').removeAttr("selected");
						//$('#on_page').trigger( "change" ); 
					}if(discount == "discount-product"){
						//alert("should not ");
						$(".product-list").css("display", "none");
						$(".product-count").css("display", "none");
						$(".values").css("display", "block");
						$(".fre_prdct_btn").css("display", "none");
						$(".discount_btn").css("display", "block");
						$(".slectpdct").css("display", "none");
						$('#value').prop('required',true);
						$(".product-count").prop('required',false);
						$('#userRequest_activity').prop('required',false);
						//alert("disc"); 
						$("#cart_total").css("display", "block"); 
						$(".currency").css("display", "block"); 
						$(".currency").css("display", "block"); 
						var on_page = $( "#on_page option:selected" ).val();
						$('#on_page option[value="'+on_page+'"]').removeAttr("selected");
						//$('#on_page').trigger( "change" ); 
					} 
					
					
				/* 	$('#prdct_specified').change(function(event) {
							var specified_array = [];
							$('#userRequest_activity :selected').each(function(i, selectedval) {
								var specified_val = $(selectedval).val();
								
								specified_array.push(specified_val);

							});
							var prdct_specified = $( "#prdct_specified option:selected" ).val();
							var specified_match = specified_array.indexOf(prdct_specified);
							alert(specified_match);
							//if((specified_match != -1) && (discount == "free-product")){
							if(discount == "free-product"){
								//$('.fre_prdct_btn').attr('disabled', '');
								//alert("You Are Not Able to Select same Product!");
									alert("ifff");
							}else{
								//$('input[type="submit"]').removeAttr('disabled');
								alert("else");
							}
						}); */ 
					//
					
			});
			
			$('#prdct_specified').change(function(event) {
			
				
				var discount = $( "#discount option:selected" ).val();
				var specified_array = [];
				$('#userRequest_activity :selected').each(function(i, selectedval) {
					var specified_val = $(selectedval).val();
					
					specified_array.push(specified_val);

				});
				var prdct_specified = $( "#prdct_specified option:selected" ).val();
				var specified_match = specified_array.indexOf(prdct_specified);
				//alert(specified_match);
				if((specified_match != -1) && (discount == "free-product")){
				//if(discount == "free-product"){
					$('.fre_prdct_btn').attr('disabled', '');
					alert("You Are Not Able to Select same Product!");
						//alert("ifff"+discount);
				}else{
					$('input[type="submit"]').removeAttr('disabled');
					//alert("else"+discount);
				}
				
							//code for configurable product
			/* 	var config_prdct = $( "#prdct_specified option:selected" ).val();
				if(config_prdct == "config"){
					$('input[type="submit"]').attr('disabled', '');
					alert("You Are Not Able to Add Configurable Product!");
				}else{
					
					$('input[type="submit"]').removeAttr('disabled');
				} */
		
			}); 
			
					
			$( "#on_page" ).change(function() {
			var on_page = $( "#on_page option:selected" ).val();
				if(on_page == "Product-specific"){
					$(".specified_prdct").css("display", "block");
					$(".currency").css("display", "none");
					$("#prdct_specified").prop('required',true);
					$("#amount").prop('required',false);
					
				}
				else{
					
					$(".specified_prdct").css("display", "none");
					$(".currency").css("display", "block");
					$("#prdct_specified").prop('required',false);
					$("#amount").prop('required',true);
					var prdct_specified = $( "#prdct_specified option:selected" ).val();
					$('#prdct_specified option[value="'+prdct_specified+'"]').removeAttr("selected");
				}
			});
			 
			 	
			});
			</script>



    <script type="text/javascript">
        $(document).ready(function() {

			var last_valid_selection = null;
			var product = [];
			var pdctcnt = 0;
			var labeltext = [];
			var labelvalues = [];
          $('#userRequest_activity').change(function(event) {
			 
			var prdct_cnt = $('#userRequest_activity :selected').length;
			if(prdct_cnt == ''){
					$(".slectpdct").html('');
			}
			var nthcnt = $( "#product-count option:selected" ).val();
            if ($(this).val().length > nthcnt) {
				
              $(this).val(last_valid_selection);
            } else {
              last_valid_selection = $(this).val();
            } 
		
		/* 	  var str = "";
				$( "#userRequest_activity option:selected" ).each(function() {
					
				  str += $( this ).val() + ",";

				});
				 $( ".slectpdct" ).text( str ); */
	
			
			$(".slectpdct").html('');
			var comp_prdct_specified = $( "#prdct_specified option:selected" ).val();
			//alert(comp_prdct_specified);
			$('#userRequest_activity :selected').each(function(i, selectedElement) {
				 if(selectedElement != '' ){
					 
				 labeltext[i] = $(selectedElement).text();
				 labelvalues[i] = $(selectedElement).val();
				 //alert(labelvalues[i]);
				 $(".slectpdct").append('<div id="remove-'+labelvalues[i]+'" class="vR"><span class="vN bfK a3q"><div class="vT">'+  labeltext[i] +'</div><div id="'+labelvalues[i]+'"  class="vM"></div></div><input type="hidden" value="'+  labeltext[i] +'" name="product_name[]"><input type="hidden" value="'+  labelvalues[i] +'" name="product_id[]">');
				 }
					if(comp_prdct_specified == labelvalues[i]){
						 $( "#remove-"+labelvalues[i] ).html('');
					 }
			});
		$('#prdct_specified').trigger( "change" ); 
          });
		  
		  $(document).on('click',  '.vM', function(){
			 // function ConfirmDelete(){
				  var x = confirm("Are you sure you want to delete?");
				 if (x == true){
					var id =  $(this).attr('id');
					$('#userRequest_activity option[value="'+id+'"]').removeAttr("selected");
					$('#userRequest_activity').trigger( "change" );
				
				
				// $('#prdct_specified option[value="'+prdct_specified+'"]').removeAttr("selected");
					$('#prdct_specified').trigger( "change" ); 
				}else{
					return false;
				}
			//}
		  });
		  
        });
        </script>

