<?php
//include_once($_SERVER['DOCUMENT_ROOT'].'/woocommerce/wp-config.php' );
 global $wpdb;
 $delete_id = $_POST['remove_id'];
 $update_id = $_POST['update_id'];
 $qryy_delete=$wpdb->query("DELETE  FROM  wp_freeproduct where product_id='$delete_id' AND prdct_specified='$update_id'"); 
 if($qryy_delete){
	 echo "sucess";
 } 

?>