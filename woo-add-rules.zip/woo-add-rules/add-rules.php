<?php
//error_reporting(0);
/**
* Plugin Name: Add Woo Rules
* Plugin URI: http://localhost/woocommerce/
* Description: Add new rule on discount 
* Version: 1.0
* Author: kbiz Soft
* Author URI: http://localhost/woocommerce/
**/
add_action('admin_menu', 'get_plugin');

function get_plugin(){
    add_menu_page( 'Add new rule', 'Add Woo Rules', 'manage_options', 'add-rule', 'add_init' );
	add_submenu_page('add-rule','Listing', 'Free Product Rules List', 'manage_options','freeprdct-list', 'freeprdct_list');
	add_submenu_page('add_init','list', '', 'manage_options','update-freeprdct', 'update_freeprdct');
	add_submenu_page('add_init','form', '', 'manage_options','add-form', 'add_form');
	add_submenu_page('add-rule','Listing', 'Discount Rules List', 'manage_options','discount-list', 'discount_list');
	add_submenu_page('add_init','list', '', 'manage_options','update-discount', 'update_discount');
	add_submenu_page('add_init','list', '', 'manage_options','delete-free-prdct', 'delete_free_prdct');
	add_submenu_page('add_init','list', '', 'manage_options','remove-free-prdct', 'remove_free_prdct');
	
	
		 add_menu_page( 'contest Plugin Page', 'Contest Plugin', 'manage_options', 'contest-plugin', 'contest_init' );
	add_submenu_page('contest-plugin','Listing', 'Approved Listings', 'manage_options','approved', 'approved_users');

}

define("MY_PLUGIN_DIR", plugin_dir_path( __FILE__ ));
define("MY_PLUGIN_URL", plugins_url('woo-add-rules'));

	 	function add_init(){
	include(MY_PLUGIN_DIR.'view/freeprdct_list.php');
	}
	add_shortcode( 'add_details', 'add_init' );

	function add_form(){
		include(MY_PLUGIN_DIR.'view/form-rule.php');
	}
	function freeprdct_list(){
		include(MY_PLUGIN_DIR.'view/freeprdct_list.php');
	}
	function update_freeprdct(){
		include(MY_PLUGIN_DIR.'view/update-freeprdct.php');
	}
	function discount_list(){
		include(MY_PLUGIN_DIR.'view/discount_list.php');
	}
	function update_discount(){
		include(MY_PLUGIN_DIR.'view/update-discount.php');
	}
	function delete_free_prdct(){
		include(MY_PLUGIN_DIR.'view/delete_free_prdct.php');
	}
	function remove_free_prdct(){
		include(MY_PLUGIN_DIR.'view/remove_free_prdct.php');
	}
	//functions on cart pages
include(MY_PLUGIN_DIR.'function.php');

function prefix_add_footer_styles() {
    wp_enqueue_style( 'modal-style',  MY_PLUGIN_URL. '/css/modal-style.css' );
};
add_action( 'get_footer', 'prefix_add_footer_styles' );
	
function wpb_adding_scripts() {
wp_register_script('modal', MY_PLUGIN_URL. '/js/modal.js','','1.1', true);
wp_enqueue_script('modal');
}
add_action( 'get_footer', 'wpb_adding_scripts' ); 

/* By kbiz Starts*/
				
function create_tbl(){
 global $wpdb;
 $table_name = $wpdb->prefix . 'discount_form';
 $sql = "CREATE TABLE $table_name (
        id int(9) NOT NULL AUTO_INCREMENT,
		rule_name varchar(22),
		discount_type varchar(22),
        percentage varchar(22),
        on_page varchar(22),
        prdct_specified varchar(22),
		currency varchar(22),
		PRIMARY KEY  (id)
        );";
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );	
 }
// run the install scripts upon plugin activation
register_activation_hook(__FILE__,'create_tbl');

/******Delete table ******/
function pluginUninstall() {
    global $wpdb;
    $table = $wpdb->prefix."discount_form";
	$wpdb->query("DROP TABLE IF EXISTS $table");
}
register_deactivation_hook( __FILE__, 'pluginUninstall' );



function create_tb2(){
 global $wpdb;
 $table_name = $wpdb->prefix . 'freeproduct';
 $sql = "CREATE TABLE $table_name (
        id int(9) NOT NULL AUTO_INCREMENT,
		rule_name varchar(22),
		free_product varchar(22),
        product_name varchar(22),
        product_id varchar(22),
        on_page varchar(22),
		prdct_specified varchar(22),
		currency varchar(22),
		status varchar(22),
		PRIMARY KEY  (id)
        );";
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );	
 }
// run the install scripts upon plugin activation
register_activation_hook(__FILE__,'create_tb2');

/******Delete table ******/
function pluginUninstall2() {
    global $wpdb;
    $table = $wpdb->prefix."freeproduct";
	$wpdb->query("DROP TABLE IF EXISTS $table");
}
register_deactivation_hook( __FILE__, 'pluginUninstall2' );


function create_tb3(){
 global $wpdb;
 $table_name = $wpdb->prefix . 'gifts_product';
 $sql = "CREATE TABLE $table_name (
        id int(9) NOT NULL AUTO_INCREMENT,
		cart_id varchar(22),
		main_product_id varchar(22),
        product_id varchar(22),
		PRIMARY KEY  (id)
        );";
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );	
 }
// run the install scripts upon plugin activation
register_activation_hook(__FILE__,'create_tb3');

/******Delete table ******/
function pluginUninstall3() {
    global $wpdb;
    $table = $wpdb->prefix."gifts_product";
	$wpdb->query("DROP TABLE IF EXISTS $table");
}
register_deactivation_hook( __FILE__, 'pluginUninstall3' );

