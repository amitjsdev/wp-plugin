     jQuery(document).ready(function () {
           jQuery(document).on('click', '.myBtn', function () {
                jQuery('#myModal').css('display', 'block');
            });
			
			   jQuery(document).on('click', '.close', function () {
                jQuery('#myModal').css('display', 'none');
            });
			
			
		
			jQuery(document).on('click', '.remove', function () {
				var data_product_id =  jQuery(this).attr("data-product_id");
				//alert(data_product_id);
				var p_url = jQuery('.for_url').val(); 
				
				function myfunction(){
					setTimeout(function(){
						window.location.reload(); 
					}, 1000);
				}
					
					
				var value={'remove_id': data_product_id};
				jQuery.ajax({
					type: "POST",	
					url: p_url,
					data: value, 
					success: function(data){
						myfunction();
					}
				});
			
			});
        });
		